<?php include_once("connection.php");
      
    include("header.php");
    $statement = $conn->query('SELECT menu FROM menu ');
    $user = $statement->fetchAll();
    $id = $_GET['id'];

    $ambilnama = $conn->query("SELECT * FROM pesanan WHERE id='$id'");
    $nama = $ambilnama->fetch();
?>

<div class="container">
    <form class="container" action="update.php?id=<?php echo $_GET['id']; ?>" method="post">
        <div class="input-group mb-3">
            <input type="text" class="form-control" name="nama" placeholder="Nama" value="<?=$nama['nama'] ?>" aria-label="Nama" aria-describedby="basic-addon1">
        </div>
        
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <label class="input-group-text" for="pesanan">Pilih Potongan Ayam</label>
            </div>
            <select class="custom-select" name="pesanan" id="pesanan">
                <?php foreach($user as $user){?>
                <option value="<?php echo $user['menu']; ?>"<?php if($user["menu"]==$nama["pesanan"])echo"selected"?>><?php echo $user['menu']; ?></option>
                <?php }?>
            </select>
        </div>
        
        <div class="input-group mb-3">
            <input type="number" class="form-control" name="jumlah" placeholder="Jumlah" value="<?=$nama['jumlah'] ?>" aria-label="Jumlah" aria-describedby="basic-addon1">
        </div>
        <button type="submit" class="btn btn-light">Update</button>
    </form>
</div>

<table class="table container">
    <caption style="text-align: center; caption-side: top;"><h5>Daftar Menu</h5></caption>
	<thead>
    <tr class="bg-warning text-dark">
        <th>Id</th>
        <th>Menu</th>
        <th>Harga</th>
    </tr>
    </thead>
    <?php $menu = $conn->query('SELECT * FROM menu '); ?>

    <?php if($menu->rowCount() > 0): ?>
        <?php 
            $no = 1; 
            foreach($menu->fetchAll(PDO::FETCH_ASSOC) AS $row): 
        ?>  
            <tr>
                <td> <?php echo $row['id']; ?> </td>
                <td> <?php echo $row['menu']; ?> </td>
                <td> <?php echo $row['harga']; ?> </td>
            </tr>
        <?php 
            $no++; 
            endforeach; 
        ?>
		
    <?php endif; ?>

</table>


