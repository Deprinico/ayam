<?php include_once("connection.php"); 
      include("header.php"); ?>  

<table class="table container"> 
    <caption style="text-align: center; caption-side: top;" class="text-dark"><h5><b>Daftar Menu</b></h5></caption>
	<thead>
    <tr class="bg-warning text-dark">
        <th>Id</th>
        <th>Menu</th>
        <th>Harga</th>
    </tr>
    </thead>
    <?php $menu = $conn->query('SELECT * FROM menu '); ?>

    <?php if($menu->rowCount() > 0): ?>
        <?php 
            $no = 1; 
            foreach($menu->fetchAll(PDO::FETCH_ASSOC) AS $row): 
        ?>  
            <tr>
                <td> <?php echo $row['id']; ?> </td>
                <td> <?php echo $row['menu']; ?> </td>
                <td> <?php echo $row['harga']; ?> </td>
            </tr>
        <?php 
            $no++; 
            endforeach; 
        ?>
		
    <?php endif; ?>

</table>


