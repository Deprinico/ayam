<?php include_once("connection.php"); 
      include("header.php"); ?>  

<style>
    .cover{
    padding-top: 0px;
    text-align: center;
    }
</style>

<div style="margin-top: 0px ;">
<table class="table">
<div>
    <caption style="text-align: center; caption-side: top; background-image:url(../foto/a.png);
        background-size: cover;
        height: 15vh;" class="text-dark"><h3><b>Data Pesanan Penjualan <br> Ayam Goreng</b></h3></caption>
</div>	
    <thead>
    <tr class="bg-warning text-dark">
        <th>Id</th>
        <th>Pembeli</th>
        <th>Pesanan</th>
        <th>Jumlah</th>
        <th>Total harga</th>
        <th>Action</th>
    </tr>
    </thead>
    <?php $query = $conn->query('SELECT * FROM pesanan'); ?>

    <?php if($query->rowCount() > 0): ?>
        <?php 
            $no = 1; 
            foreach($query->fetchAll(PDO::FETCH_ASSOC) AS $row): 
        ?>  
            <tr>
                <td> <?php echo $row['id']; ?> </td>
                <td>Saudara <?php echo $row['nama']; ?> </td>
                <td> <?php echo $row['pesanan']; ?> </td>
                <td> <?php echo $row['jumlah']; ?> Potong</td>
                <td>Rp.<?php echo $row['total_harga']; ?> </td>
                <td> 
                    <a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a>
                    <a href="delete.php?id=<?php echo $row['id']; ?>" style="margin-left: 10px;">Delete</a>
                </td>
            </tr>
        <?php 
            $no++; 
            endforeach; 
        ?>
    <?php else: ?>        
        <tr>
            <th colspan="5">Belum ada data Pembeli</th>
        </tr>		
    <?php endif; ?>

</table>

<a href="create.php" class="btn btn-warning">Tambah Pesanan</a>





