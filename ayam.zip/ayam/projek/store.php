<?php

    include_once('connection.php');
    $nama = $_POST['nama'];
    $pesanan = $_POST['pesanan'];
    $jumlah = $_POST['jumlah'];
    $call_harga = $conn->query("SELECT harga FROM menu WHERE menu='$pesanan'");
    $harga = $call_harga->fetch();
    $total_harga = $harga[0] * $jumlah;

    $statement = $conn->prepare('INSERT INTO pesanan (nama, pesanan, jumlah, total_harga)
                                            VALUES (:nama, :pesanan, :jumlah, :total_harga)');
                                
    $statement->execute([
        'nama' => $nama,
		'pesanan' => $pesanan,
        'jumlah' => $jumlah,
        'total_harga' => $total_harga
    ]);

     header('location: index.php');
?>