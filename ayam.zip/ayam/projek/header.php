<head>
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="stylesheet" href="../cit/dist/css/bootstrap.min.css">
</head>

<script src="../cit/jquery-3.3.1.slim.min.js"></script>
<script src="../cit/dist/js/bootstrap.min.js"></script>

<title>De_Nickrdys Project</title>


<nav class="navbar navbar-expand-lg navbar-light bg-warning text-dark">
  <img src="../foto/ayam.png" style="height: 100px ;">
  <a class="navbar-brand" href="#">Chicken</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="index.php">Home</a>
      <a class="nav-item nav-link" href="price.php">Pricing</a>
      <a class="nav-item nav-link" href="about.php">About</a>
    </div>
  </div>
</nav>