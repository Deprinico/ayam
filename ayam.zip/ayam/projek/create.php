<?php include_once("connection.php"); 

    include("header.php");
    $statement = $conn->query('SELECT menu FROM menu ');
    $user = $statement->fetchAll();
?> 

<head>
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="stylesheet" href="cit/dist/css/bootstrap.min.css">
</head>

<script src="cit/jquery-3.3.1.slim.min.js"></script>
<script src="cit/dist/js/bootstrap.min.js"></script>

<style>
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
    }
</style>

<div class="container" style="margin-top: 20px ;">
    <form class="container" action="store.php" method="post">
        <div class="input-group mb-3">
            <input type="text" class="form-control" name="nama" placeholder="Nama" aria-label="Nama" aria-describedby="basic-addon1">
        </div>
        
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <label class="input-group-text bg-warning" for="pesanan">Pilih Potongan Ayam</label>
            </div>
            <select class="custom-select" name="pesanan" id="pesanan">
                <?php foreach($user as $user){?>
                <option value="<?php echo $user['menu']; ?>"><?php echo $user['menu']; ?></option>
                <?php }?>
            </select>
        </div>
        
        <div class="input-group mb-3">
            <input type="number" class="form-control" name="jumlah" placeholder="Jumlah" aria-label="Jumlah" aria-describedby="basic-addon1">
        </div>
        <button type="submit" class="btn btn-warning">Masukan Pesanan</button>
    </form>
</div>


<table class="table container">
    <caption style="text-align: center; caption-side: top;"><h5>Daftar Menu</h5></caption>
	<thead>
    <tr class="bg-warning text-dark">
        <th>Id</th>
        <th>Menu</th>
        <th>Harga</th>
    </tr>
    </thead>
    <?php $menu = $conn->query('SELECT * FROM menu '); ?>

    <?php if($menu->rowCount() > 0): ?>
        <?php 
            $no = 1; 
            foreach($menu->fetchAll(PDO::FETCH_ASSOC) AS $row): 
        ?>  
            <tr>
                <td> <?php echo $row['id']; ?> </td>
                <td> <?php echo $row['menu']; ?> </td>
                <td> <?php echo $row['harga']; ?> </td>
            </tr>
        <?php 
            $no++; 
            endforeach; 
        ?>
		
    <?php endif; ?>

</table>