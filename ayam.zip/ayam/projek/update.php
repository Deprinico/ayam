<?php include_once('connection.php');

    $nama = $_POST['nama'];
    $pesanan = $_POST['pesanan'];
    $jumlah = $_POST['jumlah'];
    $id = $_GET['id'];
    $call_harga = $conn->query("SELECT harga FROM menu WHERE menu='$pesanan'");
    $harga = $call_harga->fetch();
    $total_harga = $harga[0] * $jumlah;

    echo $pesanan;

    $statement = $conn->prepare("UPDATE pesanan Set nama=:nama, pesanan=:pesanan, jumlah=:jumlah, total_harga=:total_harga WHERE id=$id");
    
    $statement->execute([
       'nama' => $nama,
       'pesanan' => $pesanan,
       'jumlah' => $jumlah,
       'total_harga' => $total_harga
    ]);

     header('location: index.php');
?>