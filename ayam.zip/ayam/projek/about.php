<?php include_once("connection.php");
include("header.php") ?>  

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="text-align: center; caption-side: top; background-image:url(../foto/b.png);
        background-size: cover;
        height: 15vh;">
  <div class="container d-flex p-2">
  <div class="row">
    <div class="col">
      <img src="../foto/ayam.png">
    </div>
    <div class="col d-flex p-2" style="align-items: center;">
      <h2><b>Web data penjualan ayam ini memiliki tampilan untuk kasir dari sebuah rumah makan dengan menu berbagai macam potong ayam.<br> Tujuan dari pembuatan web ini adalah untuk menyelesaikan tugas akhir semester 2 mata kuliah Pemrograman Web 1 yang di ampu oleh Bapak Harsanto, SE, S.Kom., M.Si</b></h2>
    </div>
  </div>
  </div>
</body>
</html>
